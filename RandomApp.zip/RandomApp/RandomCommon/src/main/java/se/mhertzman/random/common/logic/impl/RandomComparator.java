package se.mhertzman.random.common.logic.impl;

import java.util.Comparator;

import se.mhertzman.random.common.logic.RandomServiceListener;

public class RandomComparator<T extends Comparable<? super T>> implements Comparator<T> {
	
	private RandomServiceListener randomServiceListener;
	
	public RandomComparator(RandomServiceListener randomServiceListener){
		this.randomServiceListener = randomServiceListener;
	}
	@Override
	public int compare(T o1, T o2) {
		if(o1 == null && o2 == null){
			return 0;
		}
		//What should null really represent ???, For now they means no swap
		if(o1 != null && o2 == null){
			return 1;
		}
		if(o1 == null && o2 != null){
			return -1;
		}
		if(!o1.equals(o2) && randomServiceListener != null){
			randomServiceListener.swapOccured();
		}
		return o1.compareTo(o2);
	}

}
