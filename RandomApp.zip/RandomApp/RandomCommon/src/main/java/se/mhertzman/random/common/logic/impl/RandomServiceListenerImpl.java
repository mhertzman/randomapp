package se.mhertzman.random.common.logic.impl;

import se.mhertzman.random.common.logic.RandomServiceListener;

public class RandomServiceListenerImpl implements RandomServiceListener {

	private long numberOfSwaps = 0;
	@Override
	public void swapOccured() {
		numberOfSwaps++;

	}
	public long getNumberOfSwaps() {
		return numberOfSwaps;
	}
	public void setNumberOfSwaps(long numberOfSwaps) {
		this.numberOfSwaps = numberOfSwaps;
	}

}
