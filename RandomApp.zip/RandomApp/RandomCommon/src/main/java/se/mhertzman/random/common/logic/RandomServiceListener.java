package se.mhertzman.random.common.logic;

public interface RandomServiceListener {

	public void swapOccured();
	public long getNumberOfSwaps();
}
