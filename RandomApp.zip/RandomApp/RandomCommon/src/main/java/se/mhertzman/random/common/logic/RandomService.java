package se.mhertzman.random.common.logic;

import java.util.List;

public interface RandomService<T extends Comparable<? super T>> {

	public List<Comparable<T>> sort(List<T> randoms, RandomServiceListener listener);
}
