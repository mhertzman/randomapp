package se.mhertzman.random.common.logic.impl;

import java.util.Collections;
import java.util.List;

import se.mhertzman.random.common.logic.RandomService;
import se.mhertzman.random.common.logic.RandomServiceListener;

public class RandomServiceImpl<T extends Comparable<? super T>> implements RandomService<T> {

	
	@SuppressWarnings("unchecked")
	@Override
	public List<Comparable<T>> sort(List<T> randoms, RandomServiceListener listener) {
		RandomComparator randomComparator = new RandomComparator<T>(listener);
		
		Collections.sort(randoms, randomComparator);
		
		
		return (List<Comparable<T>>) randoms;
	}

}
