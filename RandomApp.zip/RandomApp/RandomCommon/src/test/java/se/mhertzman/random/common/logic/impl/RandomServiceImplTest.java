package se.mhertzman.random.common.logic.impl;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import se.mhertzman.random.common.logic.RandomService;
import se.mhertzman.random.common.logic.RandomServiceListener;

public class RandomServiceImplTest {

	@Test
	public void testEmpty() {
		
		RandomService<Long> randomService = new RandomServiceImpl<Long>();
		List<Long> empty = new ArrayList<Long>();
		
		List<Comparable<Long>> result = randomService.sort(empty, null);
		assertNotNull(result);
		assertTrue(result.isEmpty());
		
	}
	
	@Test
	public void tesTwoElements(){
		RandomService<Long> randomService = new RandomServiceImpl<Long>();
		List<Long> randoms = new ArrayList<Long>();
		randoms.add((long) 2);
		randoms.add((long) 1);
		
		RandomServiceListener randomServiceListener = new RandomServiceListenerImpl();
		
		List<Comparable<Long>> result = randomService.sort(randoms, randomServiceListener);
		assertNotNull(result);
		assertTrue(result.size() == 2);
		assertTrue(result.get(0).compareTo((long) 1) == 0);
		assertTrue(result.get(1).compareTo((long) 2) == 0);
		assertTrue(randomServiceListener.getNumberOfSwaps() == 1);
	}

}
