package se.mhertzman.random.web.servlet;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

import se.mhertzman.random.web.config.RandomWebConfig;

public class RandomWebInitializer extends AbstractAnnotationConfigDispatcherServletInitializer{

	@Override
	protected Class<?>[] getRootConfigClasses() {
		return null;
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		return new Class[] { RandomWebConfig.class };
	}

	@Override
	protected String[] getServletMappings() {
		return new String[] { "/" };	}

}
