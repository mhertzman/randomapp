package se.mhertzman.random.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RandomWebController {
	
	String message = "Welcome to Spring MVC!";
	 
	@RequestMapping("/")
	public ModelAndView showMessage(
			@RequestParam(value = "name", required = false, defaultValue = "World") String name) {
		System.out.println("in root");
 
		ModelAndView mv = new ModelAndView();
		mv.setViewName("index");
		mv.addObject("message", message);
		mv.addObject("name", name);
		return mv;
	}
	
	@RequestMapping(value ="/create", method = RequestMethod.POST)
	public ModelAndView createNewSerie(
			@RequestParam(value = "numSamples") int numSamples,
			@RequestParam(value = "minValue") int minValue,
			@RequestParam(value = "maxValue") int maxValue){
		System.out.println("in controller/create");
		if(numSamples < 1000){
			int delta = Math.abs(maxValue - minValue);
			int min = Math.min(maxValue, minValue);
			List<Long> samples = new ArrayList<Long>();
			for(int i = 0; i < numSamples; i++){
				long value = (long) (min + delta*Math.random());
				samples.add(new Long(value));
			}
			ModelAndView mv = new ModelAndView("index");
			mv.addObject("status", 1);
			mv.addObject("numSamples", numSamples);
			mv.addObject("minValue", minValue);
			mv.addObject("maxValue", maxValue);
			mv.addObject("unorderedSerie", samples);
			return mv;
		}
		
		ModelAndView mv = new ModelAndView("index");
		mv.addObject("status", 0);
		mv.addObject("numSamples", numSamples);
		mv.addObject("minValue", minValue);
		mv.addObject("maxValue", maxValue);
		mv.addObject("unorderedSerie", null);
		return mv;
		
		
		
	}
}
