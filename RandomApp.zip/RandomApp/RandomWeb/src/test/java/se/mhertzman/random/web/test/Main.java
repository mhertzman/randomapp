package se.mhertzman.random.web.test;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.BasicConfigurator;
import org.junit.BeforeClass;
import org.junit.Test;


public class Main {
/*private Server server = null;
	
	
	@BeforeClass
    public static void setUpOnce() throws IOException {
		 BasicConfigurator.configure();
		 String current = new File(".").getCanonicalPath();
		System.setProperty("jboss.server.base.dir", current + File.separator + "jboss");
	}

	
	@Test
	public void start() throws Exception {
		server = new Server(8070);
        server.setStopAtShutdown(true);
        WebAppContext webAppContext = new WebAppContext();
        webAppContext.setContextPath("/random");
        webAppContext.setResourceBase("src/main/webapp"); 
        webAppContext.setWar("target/RandomWeb.war");
        webAppContext.setClassLoader(getClass().getClassLoader());
        
        
        server.addHandler(webAppContext);
        server.start();
        server.join();
	}*/
}
